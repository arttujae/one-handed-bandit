#pragma once
std::string NimiTarkistus();
int AsiakkaanTarkistus();
int Pelikone(int saldo, int panos);
int PelinJatkaminen(int balance);
int Ik�Tarkistus(int age);
int SaldoTarkistus(int balance, int panos);
